UltimateRealityLightScribe — Font Build Scripts Included (Amiri & Scheherazade)

This package DOES NOT embed compiled TTF font binaries to remain transparent.
Instead it includes scripts that will download the official open-source font sources
and attempt to build them into .ttf files on your machine using FontForge.

Why this approach?
 - The Amiri and Scheherazade projects are open-source (OFL) and distributed with full sources.
 - Building fonts locally ensures you obtain authentic binaries directly from the source repos.
 - This package remains small and avoids redistributing large binary font files.

Prerequisites:
 - git
 - fontforge (with command-line 'fontforge' available)
 - make, gcc, python (depending on each font's build system)
 - internet access to clone the font repos

Usage:
  chmod +x scripts/download_and_build_fonts.sh
  ./scripts/download_and_build_fonts.sh
This will clone the repos into assets/fonts/amiri and assets/fonts/scheherazade and attempt to build TTFs.

Licenses:
 - Amiri: SIL Open Font License (OFL). See amiri/LICENSE in the cloned repo.
 - Scheherazade New: SIL Open Font License (OFL). See scheherazade/LICENSE in the cloned repo.

If you prefer I can embed the compiled TTF files into the archive, but I cannot download them here due to environment constraints.
