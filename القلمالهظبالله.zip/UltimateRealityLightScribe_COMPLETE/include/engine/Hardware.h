void teachHardwareEngineering();
