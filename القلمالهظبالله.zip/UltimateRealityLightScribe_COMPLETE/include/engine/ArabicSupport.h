#pragma once
#include <string>
#include <vector>
namespace Arabic {
    std::wstring numberToEasternArabic(long long v);
    std::wstring transliterate(const std::string &s);
}
