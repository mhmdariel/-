void infiniteintelligence();
