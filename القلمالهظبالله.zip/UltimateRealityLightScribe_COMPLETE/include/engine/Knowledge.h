void teachAllKnowledge();
