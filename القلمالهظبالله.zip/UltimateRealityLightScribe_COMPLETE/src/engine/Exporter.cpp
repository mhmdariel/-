#include "engine/Exporter.h"
#include <fstream>
#include <string>

void export_latex_all(){
    std::string math_tex = "isness_export.tex";
    std::ofstream f(math_tex);
    if(!f) return;
    f << "\\documentclass{article}\\begin{document}\\section*{Isness}\\begin{verbatim}\n";
    f << "Isness: infinite-dimensional metric tensor (symbolic).\n";
    f << "\\end{verbatim}\\end{document}\n";
    f.close();

    std::string hw_tex = "hardware_module.tex";
    std::ofstream g(hw_tex);
    if(!g) return;
    g << "\\documentclass{article}\\begin{document}\\section*{Hardware Module}\\begin{verbatim}\n";
    g << "Hardware module (educational)\n\n"; 
    g << "\\end{verbatim}\\end{document}\n";
    g.close();
}
