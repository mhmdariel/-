#include "engine/ArabicSupport.h"
#include <map>
#include <locale>

std::wstring Arabic::numberToEasternArabic(long long v){
    if(v==0) return std::wstring(1,L'٠');
    if(v<0) v=-v;
    std::wstring out;
    const wchar_t digs[10]={L'٠',L'١',L'٢',L'٣',L'٤',L'٥',L'٦',L'٧',L'٨',L'٩'};
    while(v>0){ out.insert(out.begin(),digs[v%10]); v/=10; }
    return out;
}

std::wstring Arabic::transliterate(const std::string &s){
    std::map<std::string,wchar_t> m={{"a",L'ا'},{"b",L'ب'},{"s",L'س'},{"l",L'ل'},{"m",L'م'}};
    std::wstring out;
    for(size_t i=0;i<s.size();++i){
        std::string c(1,s[i]);
        auto it=m.find(c);
        if(it!=m.end()) out.push_back(it->second);
    }
    return out;
}
