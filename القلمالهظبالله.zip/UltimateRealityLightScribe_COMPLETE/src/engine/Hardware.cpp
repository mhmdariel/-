#include <iostream>

void teachHardwareEngineering(){
    std::cout << "[Hardware] Full-stack overview (educational):\n";
    std::cout << " - Electricity & circuits\n";
    std::cout << " - Digital logic & CPU architecture\n";
    std::cout << " - Embedded systems, firmware, bootloaders\n";
    std::cout << " - FPGA & HDL basics\n";
    std::cout << " - PCB workflow & manufacturing concepts\n\n";
}
