#include "engine/TreeExporter.h"
#include "engine/TreeOfLife.h"
#include <string>
#include <iostream>

void export_tree_of_life_tex() {
    const std::string out = "tree_of_life_arabic.tex";
    exportTreeOfLifeLaTeX(out);
    std::cout << "[TreeExporter] LaTeX exported to: "tree_of_life_arabic.tex"\n";
}
