#include "engine/RPG.h"
#include <iostream>
#include <vector>
#include <string>

struct Unit{ std::string name; int harmony; };

void runRPGDemo(){
    std::cout << "[RPG] Starting simple encounter demo...\n";
    std::vector<Unit> party = { {"Astra",80}, {"Seren",75}, {"Tala",90} };
    std::cout << "Party members:\n";
    for(auto &u: party) std::cout << " - " << u.name << " (harmony=" << u.harmony << ")\n";
    int illusions = 3;
    int turn = 0;
    while(illusions>0 && turn<10){
        std::cout << "Turn " << (turn+1) << ":\n";
        for(auto &u: party){
            if(illusions<=0) break;
            std::cout << u.name << " acts: harmonize attempt...\n";
            illusions--;
        }
        turn++;
    }
    std::cout << "Encounter ended. Remaining illusions=" << illusions << "\n\n";
}
