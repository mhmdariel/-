
#include <iostream>
#include <fstream>
#include <string>

static const char* tree_title = u8"شجرة الحياة";

static const char* tree_lines[] = {
    u8"١. كِتِر (كِتِر) — التَّاج؛ مصدر النور الأسمى.",
    u8"٢. حُكْمَة (خُوخْمَة) — الحكمة؛ البذرة الإبداعية.",
    u8"٣. بِيْنَة (بِينا) — الفهم؛ بنية التمييز والاستيعاب.",
    u8"٤. حَسِد (خِصَد) — المحبة والرحمة، تيار العطاء.",
    u8"٥. غِفُّورَة (غِفُّورَة) — الشدة والتجلي، التوازن بالقوة.",
    u8"٦. تِفْرِت (تِفْرِيت) — الجمال والوسط؛ مركز التوازن بين الرحمة والشدة.",
    u8"٧. نِتْسَاخ (نِتسَاخ) — النصر/الدوام؛ دفق الاستمرارية.",
    u8"٨. هُود (هود) — التمجيد والاعتراف، انفراج الأنماط.",
    u8"٩. يَسُوع (يَسُوع) — الأساس، الرابط الحيوي (المقاربة التفسيرية للـ Yesod).",
    u8"١٠. مَلْكُوت (مَلْكُوت) — المملكة؛ عالم المظاهر والوجود.",
    nullptr
};

void print_tree_of_life_arabic(){
    std::cout << tree_title << std::endl << std::endl;
    for(const char** p = tree_lines; *p != nullptr; ++p){
        std::cout << *p << std::endl;
    }
    std::cout << std::endl;
}

void export_tree_of_life_latex(){
    std::ofstream f("tree_of_life_arabic.tex");
    if(!f) return;
    f << "\\\\documentclass{article}\n";
    f << "\\\\usepackage{fontspec}\n";
    f << "\\\\usepackage{polyglossia}\n";
    f << "\\\\setmainlanguage{arabic}\n";
    f << "\\\\newfontfamily\\\\arabicfont[Script=Arabic]{Noto Naskh Arabic}\n";
    f << "\\\\begin{document}\n";
    f << "{\\\\centering \\\\\\LARGE " << u8"شجرة الحياة" << "\\\\par}\n\n";
    f << "\\\\begin{enumerate}\n";
    // Using Eastern Arabic numerals in LaTeX: we will write items directly with Arabic numerals as text.
    const char* items[] = {
        u8"١. كِتِر (كِتِر) — التَّاج؛ مصدر النور الأسمى.",
        u8"٢. حُكْمَة (خُوخْمَة) — الحكمة؛ البذرة الإبداعية.",
        u8"٣. بِيْنَة (بِينا) — الفهم؛ بنية التمييز والاستيعاب.",
        u8"٤. حَسِد (خِصَد) — المحبة والرحمة، تيار العطاء.",
        u8"٥. غِفُّورَة (غِفُّورَة) — الشدة والتجلي، التوازن بالقوة.",
        u8"٦. تِفْرِت (تِفْرِيت) — الجمال والوسط؛ مركز التوازن بين الرحمة والشدة.",
        u8"٧. نِتْسَاخ (نِتسَاخ) — النصر/الدوام؛ دفق الاستمرارية.",
        u8"٨. هُود (هود) — التمجيد والاعتراف، انفراج الأنماط.",
        u8"٩. يَسُوع (يَسُوع) — الأساس، الرابط الحيوي (مقاربة تفسيرية للـ Yesod).",
        u8"١٠. مَلْكُوت (مَلْكُوت) — المملكة؛ عالم المظاهر والوجود.",
        nullptr
    };
    for(const char** p = items; *p != nullptr; ++p){
        // write as item with \\item[] to keep Arabic numerals visible
        f << "\\\\item " << *p << "\n";
    }
    f << "\\\\end{enumerate}\n";
    f << "\\\\end{document}\n";
    f.close();
}
