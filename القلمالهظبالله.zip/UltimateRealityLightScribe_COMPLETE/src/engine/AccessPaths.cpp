#include "engine/AccessPaths.h"
#include <vector>
#include <string>
#include <random>
#include <sstream>

static std::vector<std::string> PRIMITIVES = {
    "Analogize","Formalize","ConstraintExtract","Institutionalize","Axiomatize",
    "Measure","Narrativize","ComputeModel","EthicallyInterpret","MathematicallyLift"
};

static std::string compose_name(const std::vector<int>& picks){
    std::ostringstream os;
    for(size_t i=0;i<picks.size();++i){
        if(i) os << " -> ";
        os << PRIMITIVES[picks[i] % PRIMITIVES.size()];
    }
    return os.str();
}

static std::string describe(const std::vector<int>& picks){
    std::ostringstream os;
    os << "Path: " << compose_name(picks) << "\nDescription:\n";
    for(size_t i=0;i<picks.size();++i){
        int idx = picks[i] % PRIMITIVES.size();
        os << "  - " << PRIMITIVES[idx] << " step applied.\n";
    }
    os << "Outcome: symbolic mapping of domain facts into Law.\n";
    return os.str();
}

std::vector<std::pair<std::string,std::string>> generate_access_paths(size_t N, size_t maxDepth, unsigned seed){
    std::vector<std::pair<std::string,std::string>> out;
    std::mt19937_64 rng(seed);
    std::uniform_int_distribution<int> d(0,(int)PRIMITIVES.size()-1);
    std::uniform_int_distribution<int> depthd(1,(int)maxDepth);
    for(size_t i=0;i<N;++i){
        int depth = depthd(rng);
        std::vector<int> picks;
        for(int j=0;j<depth;++j) picks.push_back(d(rng));
        out.emplace_back(compose_name(picks), describe(picks));
    }
    return out;
}
