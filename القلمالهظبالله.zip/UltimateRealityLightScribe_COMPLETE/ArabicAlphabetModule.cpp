
// ArabicAlphabetModule.cpp
#include <iostream>
#include <string>
#include <vector>
#include <codecvt>
#include <locale>

static const std::vector<std::u32string> ARABIC_LETTERS = {
    U"\u0621",U"\u0622",U"\u0623",U"\u0624",U"\u0625",U"\u0626",U"\u0627",
    U"\u0628",U"\u0629",U"\u062A",U"\u062B",U"\u062C",U"\u062D",U"\u062E",
    U"\u062F",U"\u0630",U"\u0631",U"\u0632",U"\u0633",U"\u0634",U"\u0635",
    U"\u0636",U"\u0637",U"\u0638",U"\u0639",U"\u063A",U"\u0641",U"\u0642",
    U"\u0643",U"\u0644",U"\u0645",U"\u0646",U"\u0647",U"\u0648",U"\u0649",
    U"\u064A"
};
static const std::vector<std::u32string> EASTERN_ARABIC_NUMERALS = {
    U"\u0660",U"\u0661",U"\u0662",U"\u0663",U"\u0664",
    U"\u0665",U"\u0666",U"\u0667",U"\u0668",U"\u0669"
};
static const std::vector<std::u32string> ARABIC_TASHKEEL = {
    U"\u064B",U"\u064C",U"\u064D",U"\u064E",
    U"\u064F",U"\u0650",U"\u0651",U"\u0652"
};

std::string toUTF8(const std::u32string &s32) {
    static std::wstring_convert<std::codecvt_utf8<char32_t>, char32_t> conv;
    return conv.to_bytes(s32);
}

void printArabicLetters(){
    for (auto &c:ARABIC_LETTERS) std::cout<<toUTF8(c)<<" ";
    std::cout<<"\n";
}
void printEasternArabicNumerals(){
    for (auto &c: EASTERN_ARABIC_NUMERALS) std::cout<<toUTF8(c)<<" ";
    std::cout<<"\n";
}
void printArabicTashkeel(){
    for (auto &c: ARABIC_TASHKEEL) std::cout<<toUTF8(c)<<" ";
    std::cout<<"\n";
}

int main(){
    std::cout<<"Arabic module loaded.\n";
    printArabicLetters();
    printEasternArabicNumerals();
    printArabicTashkeel();
    return 0;
}
