#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build"
mkdir -p "$BUILD"
cd "$BUILD"
cmake .. -DWITH_IMGUI=OFF -DWITH_SFML=OFF -DWITH_CPACK=OFF
cmake --build . --config Release -j$(nproc)
echo "Build done at $BUILD/urs"
