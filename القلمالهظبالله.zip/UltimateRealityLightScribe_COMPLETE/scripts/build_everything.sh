#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
# fetch fonts
./scripts/fetch_fonts.sh || echo "Font fetch may have failed; continuing."

# build C++ project
mkdir -p build && cd build
cmake .. -DWITH_IMGUI=OFF -DWITH_SFML=OFF
cmake --build . -- -j$(nproc)

# Run the program to generate LaTeX/SVG outputs
cd "$ROOT"
if [ -f "./build/urs" ]; then
  ./build/urs || true
fi

# Try to run xelatex on generated tree_of_life_arabic.tex if xelatex available
if command -v xelatex >/dev/null 2>&1; then
  echo "Running xelatex to produce PDF from tree_of_life_arabic.tex..."
  xelatex -interaction=nonstopmode -output-directory="$ROOT" tree_of_life_arabic.tex || echo "xelatex run failed."
else
  echo "xelatex not installed; skipping PDF generation."
fi

echo "Build and asset fetch completed."
