#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/assets/fonts"
mkdir -p "$ASSETS"

echo "This script will download Amiri and Scheherazade font sources and build TTFs using FontForge."
echo "You need: git, fontforge (with command-line 'fontforge' tool), Python (for fontforge scripting)."
read -p "Continue? (y/n) " yn
if [ "$yn" != "y" ]; then echo "Aborted."; exit 1; fi

cd "$ASSETS"

# Amiri: clone and build
if [ ! -d "amiri" ]; then
  echo "Cloning Amiri repository..."
  git clone https://github.com/alif-type/amiri.git amiri || { echo "git clone failed; ensure network access."; exit 1; }
fi
cd amiri
# Amiri uses SFD sources and makefile; attempt build with fontforge or provided build system
if [ -f "Makefile" ]; then
  echo "Building Amiri using make..."
  make || echo "Make failed; attempting fontforge direct build."
fi
# Fallback: try fontforge to convert SFD to TTF if present
if command -v fontforge >/dev/null 2>&1; then
  echo "Attempting to generate TTF via fontforge..."
  for sfd in *.sfd; do
    [ -f "$sfd" ] || continue
    out="${sfd%.sfd}.ttf"
    if [ ! -f "$out" ]; then
      fontforge -lang=ff -c "Open('$sfd'); Generate('$out')" || echo "fontforge failed for $sfd"
    fi
  done
fi
# copy any produced TTFs to assets root
cp -v *.ttf "$ASSETS/" || true

cd "$ASSETS"

# Scheherazade New: clone and build
if [ ! -d "scheherazade" ]; then
  echo "Cloning Scheherazade New repository..."
  git clone https://github.com/silnrsi/scheherazade-new.git scheherazade || { echo "git clone failed; ensure network access."; exit 1; }
fi
cd scheherazade
# Many projects include build scripts; try source build
if [ -f "build.sh" ]; then
  chmod +x build.sh
  ./build.sh || echo "build.sh failed; attempting fontforge direct build."
fi
# Try to produce TTFs using fontforge if SFD/UFO present
if command -v fontforge >/dev/null 2>&1; then
  for sfd in *.sfd; do
    [ -f "$sfd" ] || continue
    out="${sfd%.sfd}.ttf"
    fontforge -lang=ff -c "Open('$sfd'); Generate('$out')" || echo "fontforge failed for $sfd"
  done
fi
cp -v *.ttf "$ASSETS/" || true

echo "Done. Check $ASSETS for generated TTF files. If none were generated, inspect the cloned repos and build instructions."
echo "Note: Building fonts may require additional Python packages or tools; consult each project's README."
