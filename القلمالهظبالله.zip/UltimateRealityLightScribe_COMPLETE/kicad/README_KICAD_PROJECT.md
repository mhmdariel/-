KiCad Project Skeleton (educational, safe)
- This folder contains templates and a lab notebook.
- Do NOT fabricate without review. Only use low-voltage exercises.
