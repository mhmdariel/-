Lab Notebook (safe low-voltage)
1) Project: Minimal LED board (3.3V)
2) Steps: breadboard verify -> schematic -> PCB -> DRC -> fab
3) Safety: use USB power only, verify voltages with multimeter
