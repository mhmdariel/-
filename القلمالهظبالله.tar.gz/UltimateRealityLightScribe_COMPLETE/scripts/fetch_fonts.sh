#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/assets"
mkdir -p "$ASSETS"
echo "Downloading Noto Naskh Arabic and Amiri (OFL licensed) into $ASSETS ..."
if command -v curl >/dev/null 2>&1; then
  echo "Downloading Noto Naskh Arabic..."
  curl -L -o "$ASSETS/NotoNaskhArabic-Regular.ttf" "https://github.com/googlefonts/noto-fonts/raw/main/phaseIII_only/unhinted/otf/NotoNaskhArabic/NotoNaskhArabic-Regular.ttf" || true
  echo "Downloading Amiri..."
  curl -L -o "$ASSETS/Amiri-Regular.ttf" "https://github.com/alif-type/amiri/raw/master/ttf/Amiri-Regular.ttf" || true
else
  echo "curl not found. Please download fonts manually into $ASSETS/ and name them:"
  echo " - NotoNaskhArabic-Regular.ttf"
  echo " - Amiri-Regular.ttf"
fi
echo "Done. Verify files in $ASSETS."
