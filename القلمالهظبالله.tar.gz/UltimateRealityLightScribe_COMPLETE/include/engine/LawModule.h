void law_formal_definition();
