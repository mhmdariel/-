std::vector<std::pair<std::string,std::string>> generate_access_paths(size_t N, size_t maxDepth, unsigned seed);
