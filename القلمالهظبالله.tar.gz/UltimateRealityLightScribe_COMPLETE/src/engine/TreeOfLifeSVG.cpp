\
#include <iostream>
#include <fstream>
#include <string>

void export_tree_of_life_svg(){
    std::string out = "tree_of_life_arabic.svg";
    std::ofstream f(out);
    if(!f){ std::cerr<<"Failed to open "<<out<<" for writing\\n"; return; }
    f << R"(<?xml version="1.0" encoding="UTF-8" standalone="no"?>)";
    f << "\n";
    f << R"(<svg xmlns="http://www.w3.org/2000/svg" width="800" height="1200" viewBox="0 0 800 1200">)";
    f << "\n";
    f << R"(<style> .arab { font-family: 'Noto Naskh Arabic', Amiri, serif; font-size:24px; fill:#111111; } .title { font-size:36px; font-weight:bold; }</style>)";
    f << "\n";
    f << R"(<rect width="100%" height="100%" fill="white"/>)" << "\n";
    f << R"(<text x="400" y="60" text-anchor="middle" class="title arab">شجرة الحياة</text>)" << "\n";
    const char* items[] = {
        u8"١. كِتِر — التَّاج؛ مصدر النور الأسمى.",
        u8"٢. حُكْمَة — الحكمة؛ البذرة الإبداعية.",
        u8"٣. بِيْنَة — الفهم؛ بنية التمييز والاستيعاب.",
        u8"٤. حَسِد — المحبة والرحمة، تيار العطاء.",
        u8"٥. غِفُّورَة — الشدة والتجلي، التوازن بالقوة.",
        u8"٦. تِفْرِت — الجمال والوسط؛ مركز التوازن.",
        u8"٧. نِتْسَاخ — النصر/الدوام؛ دفق الاستمرارية.",
        u8"٨. هُود — التمجيد والاعتراف، انفراج الأنماط.",
        u8"٩. يَسُوع — الأساس، الرابط الحيوي.",
        u8"١٠. مَلْكُوت — المملكة؛ عالم المظاهر والوجود.",
        nullptr
    };
    int y = 120;
    for(const char** p = items; *p != nullptr; ++p){
        f << "<text x=\"100\" y=\"" << y << "\" class=\"arab\">" << *p << "</text>\n";
        y += 90;
    }
    f << "</svg>\n";
    f.close();
    std::cout << "SVG exported to " << out << std::endl;
}

// If built as part of main, this function can be called. Provide main for standalone compile.
int main(){ export_tree_of_life_svg(); return 0; }
