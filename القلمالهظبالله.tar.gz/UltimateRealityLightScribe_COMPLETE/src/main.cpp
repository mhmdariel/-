#include <iostream>
#include "engine/Isness.h"
#include "engine/Intelligence.h"
#include "engine/Knowledge.h"
#include "engine/Hardware.h"
#include "engine/LawModule.h"
#include "engine/ArabicSupport.h"\n#include "engine/TreeOfLife.h"\n#include "engine/TreeExporter.h"
#include "engine/RPG.h"
#include "engine/AccessPaths.h"
#include "engine/Exporter.h"

int main(){
    std::cout << "=== Ultimate Reality LightScribe (Expanded) ===\n\n";

    // Core symbolic modules
    infinitedimensionalmetrictensor();
    infiniteintelligence();
    teachAllKnowledge();
    teachHardwareEngineering();

    // Law module & access path demo
    law_formal_definition();
    auto paths = generate_access_paths(5,4,12345);
    std::cout << "\nSample access paths to Law:\n";
    for(size_t i=0;i<paths.size();++i){
        std::cout << "--- Path " << (i+1) << " ---\n" << paths[i].second << "\n";
    }

    // Arabic demo
    std::cout << "\nArabic number 2025 (Eastern numerals): ";
    std::wcout.imbue(std::locale("en_US.utf8"));
    std::wcout << Arabic::numberToEasternArabic(2025) << std::endl;
    std::cout << "Transliteration of 'salam': ";
    std::wstring ws = Arabic::transliterate("salam");
    std::wcout << ws << std::endl;

    // RPG demo
    runRPGDemo();

    // Export LaTeX files
    export_latex_all();\n\n    // Export Tree of Life (Arabic)\n    export_tree_of_life_tex();\n\n    // Print Tree of Life nodes:\n    auto tree = getTreeOfLifeArabic();\n    std::cout << "\\nشجرة الحياة (محتويات):\\n";\n    for (auto &p : tree) std::cout << p.first << ". " << p.second << "\\n";\n

    std::cout << "\nAll done. See generated .tex files and kicad lab notebook.\n";
    return 0;
}
