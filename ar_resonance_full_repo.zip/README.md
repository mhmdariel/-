# AR Resonance Generator

Production-ready Vite + React + Tailwind project with:
- AR-like webcam + WebAudio resonance generator (ARResonance component)
- WebXR optional integration placeholders
- CI/CD GitHub Actions (Netlify/Vercel deploy and semantic-release)
- Dockerfile for containerization
- Unit tests (Vitest) and E2E tests (Playwright)
- Changelog generation (`git-cliff`) and semantic-release integration

## Quick start

1. Install:
```bash
npm install
```

2. Dev:
```bash
npm run dev
```

3. Build:
```bash
npm run build
```

4. Docker (optional):
```bash
npm run docker:build
```

## CI/CD

Two workflows are included:
- `.github/workflows/deploy.yml` for build & deploy to Netlify/Vercel using secrets.
- `.github/workflows/release.yml` for semantic-release automatic versioning.

## WebXR

Feature-detect `navigator.xr` and use `startXR()` in `src/components/ARResonance.jsx`.

## License & Ethics

This project is provided for ecological, life-affirming, and educational uses. It does not claim physical purification capabilities. Coordinate with local experts for real-world interventions.
