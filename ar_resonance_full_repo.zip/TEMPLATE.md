# GitHub Template Instructions

To make this repository a template on GitHub:
1. Push this repository to GitHub.
2. Go to Settings -> General -> Template repository -> Check 'Template repository'.
3. Optionally, update `template.json` for default topics or files.
