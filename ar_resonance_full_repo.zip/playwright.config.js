module.exports = {
  use: {
    headless: true,
    baseURL: 'http://localhost:5173'
  }
}
