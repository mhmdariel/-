import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Sessions from './pages/Sessions'
import Settings from './pages/Settings'

export default function App(){
  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-900 via-emerald-800 to-emerald-700 text-white">
      <header className="p-4 flex items-center justify-between">
        <h1 className="text-xl font-bold">AR Resonance Generator</h1>
        <nav className="space-x-3">
          <Link to="/" className="underline">Home</Link>
          <Link to="/sessions" className="underline">Sessions</Link>
          <Link to="/settings" className="underline">Settings</Link>
        </nav>
      </header>
      <main className="p-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/sessions" element={<Sessions />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </main>
    </div>
  )
}
