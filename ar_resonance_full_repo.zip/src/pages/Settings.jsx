import React from 'react'

export default function Settings(){
  return (
    <div className="p-4 bg-white/5 rounded-lg">
      <h2 className="text-lg font-semibold">Settings</h2>
      <p className="mt-2 text-sm opacity-80">Configure presets, export/import settings, and manage device permissions.</p>
      <div className="mt-4">
        <h3 className="font-medium">Deploy & Mobile AR</h3>
        <ol className="list-decimal ml-5 text-sm opacity-80">
          <li>Build: <code>npm run build</code></li>
          <li>Deploy to static hosting (Netlify/Vercel/GitHub Pages)</li>
          <li>For mobile AR: enable HTTPS and use WebXR / ARCore wrappers</li>
        </ol>
      </div>
    </div>
  )
}
