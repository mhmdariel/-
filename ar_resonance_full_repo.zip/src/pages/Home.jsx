import React from 'react'
import ARResonance from '../components/ARResonance'

export default function Home(){
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <ARResonance />
      </div>
      <aside className="p-4 bg-white/5 rounded-lg">
        <h2 className="font-semibold text-lg">Mission</h2>
        <p className="mt-2 text-sm opacity-80">Support life-affirming practice, ecological stewardship, and community care. This is a tool for guidance and collective action, not a replacement for civic or ecological remediation.</p>

        <div className="mt-4">
          <h3 className="font-medium">Quick Actions</h3>
          <div className="mt-2 flex gap-2">
            <button className="px-3 py-1 rounded bg-emerald-500">Nurture</button>
            <button className="px-3 py-1 rounded bg-sky-600">Cleanse</button>
            <button className="px-3 py-1 rounded bg-amber-500">Gather</button>
          </div>
        </div>
      </aside>
    </div>
  )
}
