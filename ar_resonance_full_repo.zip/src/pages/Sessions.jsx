import React, { useState } from 'react'

export default function Sessions(){
  const [sessions, setSessions] = useState([])
  const create = ()=> {
    const s = { id: Date.now(), name: `Session ${sessions.length+1}`, created: new Date().toISOString() }
    setSessions([s, ...sessions])
  }
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Sessions</h2>
        <button onClick={create} className="px-3 py-1 rounded bg-emerald-500">Create Session</button>
      </div>
      <div className="space-y-2">
        {sessions.length===0 ? <div className="opacity-70">No sessions yet.</div> : sessions.map(s=>(
          <div key={s.id} className="p-3 bg-white/5 rounded flex justify-between items-center">
            <div>
              <div className="font-medium">{s.name}</div>
              <div className="text-xs opacity-70">{s.created}</div>
            </div>
            <div className="flex gap-2">
              <button className="px-2 py-1 rounded bg-sky-600">Run</button>
              <button className="px-2 py-1 rounded bg-white/10">Export</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
