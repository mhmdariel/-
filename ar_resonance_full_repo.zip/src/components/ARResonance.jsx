import React, { useEffect, useRef, useState } from 'react';

const DEFAULT_PRESETS = {
  "Rainforest Vitality": { freq: 432, detune: 0, gain: 0.15, waveform: "sine" },
  "Ocean Deep Calm": { freq: 128, detune: -2, gain: 0.12, waveform: "triangle" },
  "High Samadhi": { freq: 852, detune: 3, gain: 0.08, waveform: "sine" },
  "Balancing Drone": { freq: 210, detune: 0, gain: 0.18, waveform: "square" }
};

export default function ARResonance(){
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const audioCtxRef = useRef(null);
  const oscRef = useRef(null);
  const gainRef = useRef(null);
  const analyserRef = useRef(null);
  const animationRef = useRef(null);
  const xrRef = useRef(null);

  const [running, setRunning] = useState(false);
  const [frequency, setFrequency] = useState(432);
  const [gain, setGain] = useState(0.15);
  const [waveform, setWaveform] = useState('sine');
  const [presetName, setPresetName] = useState('Rainforest Vitality');
  const [isPurifying, setIsPurifying] = useState(false);
  const [vitality, setVitality] = useState(75);
  const [fertility, setFertility] = useState(72);
  const [balance, setBalance] = useState(80);
  const [logMessages, setLogMessages] = useState([]);
  const [xrSupported, setXrSupported] = useState(false);

  useEffect(() => {
    if (navigator.xr) {
      navigator.xr.isSessionSupported && navigator.xr.isSessionSupported('immersive-ar').then(s => setXrSupported(s)).catch(()=>{setXrSupported(false)});
    }
  }, []);

  useEffect(()=> {
    async function startCamera(){
      try {
        const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
        if (videoRef.current) videoRef.current.srcObject = s;
      } catch (err) {
        pushLog('Camera unavailable: ' + String(err));
      }
    }
    startCamera();
    return ()=> {
      if (videoRef.current && videoRef.current.srcObject){
        const tracks = videoRef.current.srcObject.getTracks();
        tracks.forEach(t=>t.stop());
      }
      stopAudio();
      cancelAnimationFrame(animationRef.current);
      stopXR();
    };
    // eslint-disable-next-line
  }, []);

  function pushLog(msg){ setLogMessages(prev => [`${new Date().toLocaleTimeString()} ${msg}`, ...prev].slice(0,40)); }

  function startAudio(){
    if (audioCtxRef.current) return;
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    audioCtxRef.current = ctx;
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 2048;
    osc.type = waveform;
    osc.frequency.setValueAtTime(frequency, ctx.currentTime);
    gainNode.gain.setValueAtTime(gain, ctx.currentTime);
    osc.connect(gainNode);
    gainNode.connect(analyser);
    analyser.connect(ctx.destination);
    osc.start();
    oscRef.current = osc; gainRef.current = gainNode; analyserRef.current = analyser;
    pushLog('Resonance started');
  }

  function stopAudio(){
    try {
      if (oscRef.current){ oscRef.current.stop(); oscRef.current.disconnect(); oscRef.current = null; }
      if (gainRef.current){ gainRef.current.disconnect(); gainRef.current = null; }
      if (audioCtxRef.current){ audioCtxRef.current.close().catch(()=>{}); audioCtxRef.current = null; }
      analyserRef.current = null;
      pushLog('Resonance stopped');
    } catch (err){ console.warn(err); }
  }

  useEffect(()=> {
    if (!audioCtxRef.current || !oscRef.current || !gainRef.current) return;
    try {
      oscRef.current.type = waveform;
      oscRef.current.frequency.setTargetAtTime(frequency, audioCtxRef.current.currentTime, 0.02);
      gainRef.current.gain.setTargetAtTime(gain, audioCtxRef.current.currentTime, 0.05);
    } catch (err){}
  }, [frequency, gain, waveform]);

  useEffect(()=> {
    function draw(){
      const canvas = canvasRef.current; const video = videoRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      const w = canvas.width = canvas.clientWidth;
      const h = canvas.height = canvas.clientHeight;
      if (video && video.readyState >= 2){
        try { ctx.drawImage(video,0,0,w,h); ctx.fillStyle='rgba(0,0,0,0.18)'; ctx.fillRect(0,0,w,h); } catch {}
      } else { ctx.fillStyle='#013220'; ctx.fillRect(0,0,w,h); }
      // mandala
      ctx.save(); ctx.translate(w/2,h/2); ctx.strokeStyle='rgba(200,255,210,0.18)';
      for (let r=0;r<6;r++){ ctx.beginPath(); ctx.arc(0,0,20 + r*14,0,Math.PI*2); ctx.stroke(); }
      ctx.restore();
      // purification particles
      if (isPurifying){
        ctx.save();
        for (let i=0;i<60;i++){
          const angle = (i / 60) * Math.PI * 2 + (Date.now()/6000);
          const radius = Math.min(w,h) * (0.08 + 0.4 * Math.abs(Math.sin(Date.now()/3000 + i)));
          const x = w/2 + Math.cos(angle) * radius;
          const y = h/2 + Math.sin(angle) * radius * 0.6;
          const size = 1 + Math.abs(Math.sin(Date.now()/400 + i))*4;
          ctx.beginPath();
          ctx.fillStyle = `rgba(240,255,230,${0.16 + Math.abs(Math.sin(i + Date.now()/500))/2})`;
          ctx.arc(x, y, size, 0, Math.PI*2);
          ctx.fill();
        }
        ctx.restore();
      }
      animationRef.current = requestAnimationFrame(draw);
    }
    animationRef.current = requestAnimationFrame(draw);
    return ()=> cancelAnimationFrame(animationRef.current);
  }, [isPurifying]);

  function applyPreset(name){
    const p = DEFAULT_PRESETS[name]; if (!p) return;
    setPresetName(name); setFrequency(p.freq); setGain(p.gain); setWaveform(p.waveform);
    pushLog('Preset ' + name + ' applied');
  }

  function toggleGenerator(){
    if (!running){ startAudio(); setRunning(true); } else { stopAudio(); setRunning(false); }
  }

  function runPurification(){
    if (!running){ pushLog('Start resonance before purification'); return; }
    setIsPurifying(true); pushLog('Purification engaged');
    const steps = 10; let i=0;
    const t = setInterval(()=>{ i++; setVitality(v=>Math.min(100,v+3)); setBalance(b=>Math.min(100,b+2)); setFertility(f=>Math.min(100,f+2)); if (i>=steps){ clearInterval(t); setIsPurifying(false); pushLog('Purification (sim) complete'); } }, 700);
  }

  // WebXR start/stop
  async function startXR(){
    if (!navigator.xr) { pushLog('WebXR not available'); return; }
    try {
      const session = await navigator.xr.requestSession('immersive-ar', { requiredFeatures: ['local'], optionalFeatures: ['hit-test'] });
      xrRef.current = session;
      pushLog('WebXR session started (placeholder)');
      // Real app: create WebGL layer and render loop bound to XR session
    } catch (err){
      pushLog('WebXR start failed: ' + String(err));
    }
  }

  function stopXR(){
    if (xrRef.current){ xrRef.current.end(); xrRef.current = null; pushLog('WebXR session ended'); }
  }

  return (
    <div className="rounded-2xl overflow-hidden shadow-lg bg-black/40 p-2">
      <div className="relative h-[60vh] rounded overflow-hidden">
        <video ref={videoRef} autoPlay muted playsInline className="absolute inset-0 w-full h-full object-cover" />
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
        <div className="absolute left-4 bottom-4 flex gap-2">
          <button onClick={toggleGenerator} className={`px-4 py-2 rounded ${running? 'bg-amber-600':'bg-emerald-500'}`}>{running? 'Stop':'Start'}</button>
          <button onClick={runPurification} disabled={!running} className="px-3 py-2 rounded bg-sky-600">Purify</button>
          {xrSupported && <button onClick={startXR} className="px-3 py-2 rounded bg-violet-600">Start AR (WebXR)</button>}
        </div>
      </div>

      <div className="mt-3 p-2 grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs">Preset</label>
          <select value={presetName} onChange={e=>applyPreset(e.target.value)} className="w-full p-2 rounded bg-black/30">
            {Object.keys(DEFAULT_PRESETS).map(k=> <option key={k} value={k}>{k}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs">Waveform</label>
          <select value={waveform} onChange={e=>setWaveform(e.target.value)} className="w-full p-2 rounded bg-black/30">
            <option value="sine">Sine</option><option value="triangle">Triangle</option><option value="square">Square</option>
          </select>
        </div>
        <div>
          <label className="text-xs">Frequency</label>
          <input type="range" min="30" max="1200" value={frequency} onChange={e=>setFrequency(Number(e.target.value))} className="w-full" />
        </div>
        <div>
          <label className="text-xs">Gain</label>
          <input type="range" min="0" max="0.5" step="0.005" value={gain} onChange={e=>setGain(Number(e.target.value))} className="w-full" />
        </div>
      </div>
    </div>
  )
}
