import { render, screen } from '@testing-library/react'
import ARResonance from '../src/components/ARResonance'

test('renders AR interface', () => {
  render(<ARResonance />)
  expect(screen.getByText(/Preset/i)).toBeInTheDocument()
})
